package com.example.pmdm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.DatePicker
import android.widget.EditText
import com.example.pmdm.MainActivity
import com.example.pmdm.R
import com.example.pmdm.model.database.LocalDatabase
import com.example.pmdm.model.entity.Usuario
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class FormularioActivity : AppCompatActivity() {

    private lateinit var editTextNombre: EditText
    private lateinit var editTextEdad: EditText
    private lateinit var datePickerFecha: DatePicker


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario)

        getElements()
    }

    fun getElements(){
        editTextNombre = findViewById(R.id.form_et_nombre)
        editTextEdad = findViewById(R.id.form_et_telefono)
        datePickerFecha = findViewById(R.id.form_dp_fecha)
    }

    fun goToMain(view: View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun siguiente(view: View){
        val intent = Intent(this, Formulario2Activity::class.java)
        startActivity(intent)

    }

    fun guardar(view: View) {
        val calendar = Calendar.getInstance()
        calendar.set(datePickerFecha.year, datePickerFecha.month, datePickerFecha.dayOfMonth)
        val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val fechaFormateada: String = formatoFecha.format(calendar.time)

        var usuario = Usuario(0, editTextNombre.text.toString(), editTextEdad.text.toString().toInt(), fechaFormateada )

        var localdb:LocalDatabase = LocalDatabase.getInstance(this)

        GlobalScope.launch(Dispatchers.IO) {
            localdb.userDao().insertAll(usuario)
        }
    }
}