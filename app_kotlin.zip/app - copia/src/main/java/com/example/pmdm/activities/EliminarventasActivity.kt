package com.example.pmdm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.pmdm.R

class EliminarventasActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_eliminarventas)
    }

    fun goToVentas(view: View) {
        val intent = Intent(this, VentasActivity::class.java)
        startActivity(intent)
    }

    fun siguiente(view: View) {
        val intent = Intent(this, MenuActivity::class.java)
        startActivity(intent)
    }
    fun recargarPaginaPrincipal(view: View) {
        val intent = Intent(this, MenuActivity::class.java)
        startActivity(intent)
    }
}