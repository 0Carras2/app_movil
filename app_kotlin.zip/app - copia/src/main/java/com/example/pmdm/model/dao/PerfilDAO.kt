package com.example.pmdm.model.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.pmdm.model.entity.Perfil
import com.example.pmdm.model.entity.Usuario


@Dao
interface PerfilDao {
    @Query("SELECT * FROM perfil")
    fun getAll(): List<Perfil>

    @Query("SELECT * FROM perfil WHERE uid IN (:userIds)")
    fun loadAllByIds(userIds: IntArray): List<Perfil>


    @Insert
    fun insertAll(vararg users: Perfil)

    @Delete
    fun delete(user: Perfil)
}