package com.example.pmdm.model.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Perfil(
    @PrimaryKey(autoGenerate = true) val uid: Long,
    @ColumnInfo(name = "CORREO") val correo: String,
    @ColumnInfo(name = "CONTRASEÑA") val contrasena: Int,


)