package com.example.pmdm.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.pmdm.R

class ConfirmacionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirmacion)
    }
}