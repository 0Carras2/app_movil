package com.example.pmdm.model.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.example.pmdm.model.entity.Usuario

@Dao
interface UsuarioDao {
    @Query("SELECT * FROM usuario")
    fun getAll(): List<Usuario>

    @Query("SELECT * FROM usuario WHERE uid IN (:userIds)")
    fun loadAllByIds(userIds: IntArray): List<Usuario>


    @Insert
    fun insertAll(vararg users: Usuario)

    @Delete
    fun delete(user: Usuario)
}





