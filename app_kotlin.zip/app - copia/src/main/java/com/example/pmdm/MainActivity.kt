package com.example.pmdm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.pmdm.activities.Formulario2Activity
import com.example.pmdm.activities.FormularioActivity
import com.example.pmdm.activities.SesionActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun goToFormulario(view: View) {
        val intent = Intent(this, FormularioActivity::class.java)
        startActivity(intent)
    }

    fun goToInicioSesion(view: View){
        val intento = Intent(this, SesionActivity::class.java)
        startActivity(intento)
    }

    fun recargarPagina(view: View) {
        val intento = Intent(this, MainActivity::class.java)
        startActivity(intento)
    }
}