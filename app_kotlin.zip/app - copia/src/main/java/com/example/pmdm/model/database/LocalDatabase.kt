package com.example.pmdm.model.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.pmdm.model.dao.UsuarioDao
import com.example.pmdm.model.entity.Usuario
import kotlin.concurrent.Volatile

@Database(entities = [Usuario::class], version = 1)
abstract class LocalDatabase : RoomDatabase() {
    abstract fun userDao(): UsuarioDao

    companion object{
        private const val DATABASE_NAME = "PMDM.db"
        @Volatile
        private var INSTANCE: LocalDatabase? = null

        fun getInstance(context: Context): LocalDatabase{
            synchronized(this){
                var instance = INSTANCE

                if(instance == null){
                    //Abrir conexión
                    instance = Room.databaseBuilder(context.applicationContext, LocalDatabase::class.java, DATABASE_NAME).build()
                    INSTANCE = instance
                }
                return instance
            }
        }
    }
}



