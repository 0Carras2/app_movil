package com.example.pmdm.activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.pmdm.MainActivity
import com.example.pmdm.R

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
    }

    fun goToMain(view: View) {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

    fun goToInsertarTarea(view: View) {
        val intent = Intent(this, TareasActivity::class.java)
        startActivity(intent)
    }

    fun goToInsertarCompra(view: View) {
        val intent = Intent(this, ComprasActivity::class.java)
        startActivity(intent)
    }

    fun goToInsertarVenta(view: View) {
        val intent = Intent(this, VentasActivity::class.java)
        startActivity(intent)
    }

    fun goToInsertarCliente(view: View) {
        val intent = Intent(this, ClientesActivity::class.java)
        startActivity(intent)
    }

}